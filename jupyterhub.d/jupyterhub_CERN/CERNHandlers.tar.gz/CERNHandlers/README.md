# CERN Handlers

Provide custom JupyterHub handlers.

## Installation

First, install dependencies:

    pip3 install -r requirements.txt

Then, install the package:

    python3 setup.py install

## Usage

Use the start_jupyterhub.py script to launch a subclassed version of the
jupyterhub application.
